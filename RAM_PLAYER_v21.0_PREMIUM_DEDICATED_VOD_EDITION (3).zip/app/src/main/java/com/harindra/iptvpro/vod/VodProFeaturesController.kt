package com.harindra.iptvpro.vod

import java.util.Locale

/**
 * Pro OTT Cinema Features Controller for Dedicated VOD Player:
 * 1. Skip Intro (+85s) smart window detection
 * 2. Quick Chapter / Percentage & ±5-Minute Jump calculations
 * 3. Screen Lock / Kids Remote Lock state
 * 4. VOD Sleep Timer (OFF / 15m / 30m / 45m / 60m / End of Title)
 * 5. Cinema Audio Dialogue Boost levels (0 / +4 / +8 / +12 dB)
 * 6. Night Dimmer Overlay levels (0% / 22% / 42%)
 * 7. Real-time Cinema Telemetry / Nerd Stats formatter
 */
enum class VodSleepTimerMode(val minutes: Int, val label: String) {
    OFF(0, "Off"),
    MIN_15(15, "15 min"),
    MIN_30(30, "30 min"),
    MIN_45(45, "45 min"),
    MIN_60(60, "60 min"),
    END_OF_TITLE(-1, "End of Title");

    fun next(): VodSleepTimerMode {
        val all = values()
        return all[(ordinal + 1) % all.size]
    }
}

enum class VodAudioBoostLevel(val gainMillibels: Int, val label: String) {
    OFF(0, "0 dB"),
    LOW(400, "+4 dB"),
    MEDIUM(800, "+8 dB"),
    HIGH(1200, "+12 dB");

    fun next(): VodAudioBoostLevel {
        val all = values()
        return all[(ordinal + 1) % all.size]
    }
}

enum class VodNightDimLevel(val overlayAlpha: Float, val label: String) {
    OFF(0.0f, "Normal"),
    SOFT(0.22f, "Night Soft"),
    DEEP(0.42f, "Night Deep");

    fun next(): VodNightDimLevel {
        val all = values()
        return all[(ordinal + 1) % all.size]
    }
}

class VodProFeaturesController {

    companion object {
        const val SKIP_INTRO_DELTA_MS = 85_000L
        const val SKIP_INTRO_WINDOW_END_MS = 240_000L
        const val MIN_DURATION_FOR_SKIP_INTRO_MS = 300_000L
    }

    var isScreenLocked: Boolean = false
        private set

    var isNerdStatsVisible: Boolean = false
        private set

    var sleepTimerMode: VodSleepTimerMode = VodSleepTimerMode.OFF
        private set

    private var sleepDeadlineMs: Long = 0L

    var audioBoostLevel: VodAudioBoostLevel = VodAudioBoostLevel.OFF
        private set

    var nightDimLevel: VodNightDimLevel = VodNightDimLevel.OFF
        private set

    fun toggleScreenLock(): Boolean {
        isScreenLocked = !isScreenLocked
        return isScreenLocked
    }

    fun unlockScreen() {
        isScreenLocked = false
    }

    fun toggleNerdStats(): Boolean {
        isNerdStatsVisible = !isNerdStatsVisible
        return isNerdStatsVisible
    }

    fun cycleAudioBoost(): VodAudioBoostLevel {
        audioBoostLevel = audioBoostLevel.next()
        return audioBoostLevel
    }

    fun cycleNightDim(): VodNightDimLevel {
        nightDimLevel = nightDimLevel.next()
        return nightDimLevel
    }

    fun setSleepTimer(mode: VodSleepTimerMode, nowMs: Long = System.currentTimeMillis()) {
        sleepTimerMode = mode
        sleepDeadlineMs = if (mode.minutes > 0) nowMs + mode.minutes * 60_000L else 0L
    }

    fun cycleSleepTimer(nowMs: Long = System.currentTimeMillis()): VodSleepTimerMode {
        val next = sleepTimerMode.next()
        setSleepTimer(next, nowMs)
        return next
    }

    fun isSleepTimerExpired(nowMs: Long = System.currentTimeMillis()): Boolean {
        if (sleepTimerMode.minutes <= 0 || sleepDeadlineMs <= 0L) return false
        return nowMs >= sleepDeadlineMs
    }

    fun remainingSleepMinutes(nowMs: Long = System.currentTimeMillis()): Int {
        if (sleepTimerMode.minutes <= 0 || sleepDeadlineMs <= 0L) return 0
        val remMs = (sleepDeadlineMs - nowMs).coerceAtLeast(0L)
        return ((remMs + 59_999L) / 60_000L).toInt()
    }

    fun shouldStopAtTitleEnd(): Boolean = sleepTimerMode == VodSleepTimerMode.END_OF_TITLE

    fun isSkipIntroEligible(positionMs: Long, durationMs: Long): Boolean {
        if (durationMs < MIN_DURATION_FOR_SKIP_INTRO_MS) return false
        return positionMs in 5_000L..SKIP_INTRO_WINDOW_END_MS
    }

    fun computeSkipIntroTarget(positionMs: Long, durationMs: Long): Long {
        val target = positionMs.coerceAtLeast(0L) + SKIP_INTRO_DELTA_MS
        return if (durationMs > 0L) target.coerceIn(0L, durationMs) else target
    }

    fun computePercentJumpTarget(durationMs: Long, percent: Int): Long {
        if (durationMs <= 0L) return 0L
        val clampedPct = percent.coerceIn(0, 99)
        return (durationMs * clampedPct.toLong()) / 100L
    }

    fun computeMinuteJumpTarget(currentPositionMs: Long, durationMs: Long, deltaMinutes: Int): Long {
        val target = currentPositionMs.coerceAtLeast(0L) + (deltaMinutes.toLong() * 60_000L)
        return if (durationMs > 0L) target.coerceIn(0L, durationMs) else target.coerceAtLeast(0L)
    }

    fun formatStatsHud(
        videoWidth: Int,
        videoHeight: Int,
        videoFps: Float,
        videoCodec: String,
        audioSummary: String,
        bitrateBps: Int,
        bufferedAheadMs: Long,
        speedLabel: String
    ): String {
        val res = if (videoWidth > 0 && videoHeight > 0) "${videoWidth}×${videoHeight}" else "Detecting"
        val fpsPart = if (videoFps > 1f) String.format(Locale.ROOT, " @ %.0ffps", videoFps) else ""
        val codecPart = videoCodec.ifBlank { "Auto" }
        val brPart = if (bitrateBps > 0) {
            val mbps = bitrateBps / 1_000_000.0
            if (mbps >= 1.0) String.format(Locale.ROOT, "%.1f Mbps", mbps) else "${bitrateBps / 1000} kbps"
        } else "Adaptive"
        val bufSec = (bufferedAheadMs.coerceAtLeast(0L) / 1000L)
        return "VIDEO: $res$fpsPart  •  $codecPart ($brPart)\nAUDIO: $audioSummary  •  SPEED: $speedLabel  •  BUFFER: +${bufSec}s"
    }
}
